          ;;  ;;          ;;  ;;
           ;;  ;;          ;;  ;;
        ;;eval$s        =%q[i=1#
         eval(%q[        xxxxxxxx
        xx  xxxx  xx    xx  xxxx  xx
         xx  xxxx  xx    xx  xxxx  xx
            xxxxxxxx        xxxxxxxx
             xxxxxxxx        xxxxxxxx
  xx  xx  xxxxxxxxxx  xx  xxxxxxxx
   j,  t,  p=0,[?;],"  ev  al$s=%qx
[#$s]".split*"";i,j,t=i-j,i+j,(x
 [b=?\s]*j.abs+t).map{|s|r=t.shix
ft  ||b;r.gsub!(?;){p.slice!0}if  $x
 f|  |=p>p=p.center(i*i+j*j,?;);r  ,x
    s=[s,r]if(i*j<0);(b*i.abs+s).ljx
     ust(r.size).gsub(b){r[$`.size]|x
  |b}}unti  l$  f;puts(t)#  xx  xx
   xxxxxxxx  xx  xxxxxxxxxx  xx  xx
xxxxxxxx        xxxxxxxx
 xxxxxxxx        xxxxxxxx
xx  xxxx  xx    xx  xxxx  xx
 xx  xxxx  xx    xx  xxxx  xx
    xxxxxxxx        x].gsub\
     /x.*|\s/        ,"")#];;
    ;;  ;;          ;;  ;;
     ;;  ;;          ;;  ;;
