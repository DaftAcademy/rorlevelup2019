This directory contains the award-winning entries of
the 1st Transcendental Ruby Imbroglio Contest for rubyKaigi (TRICK 2013).

THESE ARE BAD EXAMPLES!  You must NOT use them as a sample code.

* kinaba/entry.rb: "Best pangram" - Gold award
* mame/entry.rb: "Most classic" - Bronze award
* shinh/entry.rb: "Most Readable" - Silver award
* yhara/entry.rb: "Worst abuse of constants" - Dishonorable mention

These files are licensed under MIT license.

For the contest outline and other winning entries, see:

https://github.com/tric/trick2013
