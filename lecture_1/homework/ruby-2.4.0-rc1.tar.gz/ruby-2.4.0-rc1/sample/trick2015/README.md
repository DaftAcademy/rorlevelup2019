This directory contains the award-winning entries of
the 2nd Transcendental Ruby Imbroglio Contest for rubyKaigi (TRICK 2015).

THESE ARE BAD EXAMPLES!  You must NOT use them as a sample code.

* kinaba/entry.rb: "Best piphilology" - **Gold award**
* ksk\_1/entry.rb: "Most unreadable ALU" - **Silver award**
* monae/entry.rb: "Doubling amphisbaena award" - **Bronze award**
* eregon/entry.rb: "Least general solver" - 4th prize
* ksk\_2/entry.rb: "Most general solver" - 5th prize

These files are licensed under MIT license.

For the contest outline and other winning entries, see:

https://github.com/tric/trick2015
